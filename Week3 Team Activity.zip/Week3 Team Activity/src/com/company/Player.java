package com.company;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;
import java.util.Set;

public class Player {
    String name;
    int health;
    int mana;
    int money;
    Map<String,Integer> equipment = new HashMap<String, Integer>();

    public Player(String name, int health, int mana, int money) {
        this.name = name;
        this.health = health;
        this.mana = mana;
        this.money = money;

    }

    @Override
    public String toString() {
        return "Player{" +
                "name='" + name + '\'' +
                ", health=" + health +
                ", mana=" + mana +
                ", money=" + money +
                ", equipment=" + equipment +
                '}';
    }


    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        this.health = health;
    }

    public int getMana() {
        return mana;
    }

    public void setMana(int mana) {
        this.mana = mana;
    }

    public int getMoney() {
        return money;
    }

    public void setMoney(int money) {
        this.money = money;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }
}
