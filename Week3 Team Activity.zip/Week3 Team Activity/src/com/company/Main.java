package com.company;

import com.google.gson.Gson;

public class Main {

    public static void main(String[] args) {

        Player yourPlayer = new Player("Talon",100,50,100);
        yourPlayer.equipment.put("Longsword",45);
        yourPlayer.equipment.put("LongBow",30);
        yourPlayer.equipment.put("Dagger",15);
        yourPlayer.equipment.put("Armor",40);
        System.out.println(yourPlayer.toString());
        Game theGame = new Game(yourPlayer);
        theGame.saveGame();
        theGame.loadGame();
        theGame.loadPlayer.toString();

    }
}
