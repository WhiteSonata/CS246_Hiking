package com.company;

import com.google.gson.Gson;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;
import java.util.Scanner;

public class Game {
    Player thePlayer;
    Player loadPlayer;
    Gson g = new Gson();
    String playerJson;
    File file = new File("SaveFile.txt");

    public Game(Player player) {
        thePlayer = player;
    }

    public void saveGame(){
        String playerJson = g.toJson(thePlayer);
        PrintWriter out = null;
        try {
            out = new PrintWriter(file);
            out.println(playerJson);
            out.flush();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }

    }
    public void loadGame(){
        String fromFile = null;
        {
            try {
                Scanner sc = new Scanner(file);
                playerJson = sc.nextLine();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            }
        }


        loadPlayer = g.fromJson(playerJson, Player.class);
    }

}
