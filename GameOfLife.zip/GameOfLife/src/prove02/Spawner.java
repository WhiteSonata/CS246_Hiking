package prove02;

public interface Spawner {
    public Creature SpawnNewCreature();
}
