package prove02;


import java.awt.*;
import java.awt.Color;
import java.util.Random;

public class Wolf extends Creature implements Movable,Aware,Aggressor,Spawner {

Random _rand;
String preffered_Direction = "random";



    public Wolf() {
        _rand = new Random();
        _health = 1;
        canSpawn = false;
    }

    @Override
    public void attack(Creature target) {
        if(target instanceof Animal){
            target.takeDamage(5);
            canSpawn = true;


        }
    }

    @Override
    public void senseNeighbors(Creature above, Creature below, Creature left, Creature right) {
        if(above instanceof Animal){
            preffered_Direction = "up";

        }else if(right instanceof Animal){
            preffered_Direction = "right";

        }else if(below instanceof  Animal){
             preffered_Direction = "down";

        }else if(left instanceof Animal){
             preffered_Direction = "left";

        }else{  }
    }

    @Override
    Shape getShape() {
        return Shape.Square;
    }

    @Override
    Color getColor() {
        return new Color(145,145,145);
    }

    @Override
    Boolean isAlive() {
        return ( _health > 0);
    }

    @Override
    public void move() {
        if(preffered_Direction =="up"){
            _location.y++;
        }else if(preffered_Direction == "down"){
            _location.y--;
        }else if(preffered_Direction== "right"){
            _location.x++;
        }else if(preffered_Direction == "left"){
            _location.x--;
        }else{
            switch(_rand.nextInt(4)) {
                case 0:
                    _location.x++;
                    preffered_Direction = "right";
                    break;
                case 1:
                    _location.x--;
                    preffered_Direction ="left";
                    break;
                case 2:
                    _location.y++;
                    preffered_Direction = "up";
                    break;
                case 3:
                    _location.y--;
                    preffered_Direction = "down";
                    break;
                default:
                    break;
            }
        }
    }

    @Override
    public Creature SpawnNewCreature() {
       Point startingpoint = new Point(0,0);
        Wolf baby = new Wolf();
        baby._location = startingpoint;
        canSpawn=false;
       return baby;

    }
}
