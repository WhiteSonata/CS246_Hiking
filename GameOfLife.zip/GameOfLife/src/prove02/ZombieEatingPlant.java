package prove02;

import prove02.Aggressor;
import prove02.Creature;
import prove02.Shape;

import java.awt.*;

public class ZombieEatingPlant extends Creature implements Aggressor {
    public ZombieEatingPlant() {
        _health = 1;

    }

    @Override
    public void attack(Creature target) {
        if(target instanceof Zombie){
            target.takeDamage(4);
            _health+=2;
        }

    }

    @Override
    Shape getShape() {
        return Shape.Circle;
    }

    @Override
    Color getColor() {
        return new Color(92,0,92);
    }

    @Override
    Boolean isAlive() {
        return (_health > 0);
    }
}
